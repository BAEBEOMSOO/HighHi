import java.util.Arrays;

public class May_05_27_05 {

	public static void main(String[] args) {

	//������ Ǯ��
		int[] freq = new int[10];
		
		for(int i = 0; i<100; i++) {
			int n = (int)(Math.random()*10);
			freq[n] ++; //n�迭�� 1�� ����
//			freq[(int)(Math.random()*10)]++;
		}
		
		int m = 0;
		
		for(int i = 1; i<freq.length; i++){
			if(freq[i]>freq[m])
				m = i;
		}
		
		for (int i = 0; i < freq.length; i++) {
			System.out.printf("%d:%4dȸ\n",i,freq[i]);
		}
			System.out.printf("\n�ֺ�:%d, �ֺ��� �󵵼�:%d\n",m,freq[m]);
		
		
		
		
		
		
		
		
	}

}
